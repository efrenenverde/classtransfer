package BolArr;

public class Enunciados {
//	1. Leer 5 n�meros y mostrarlos en el mismo orden introducido.
//	2. Leer 5 n�meros y mostrarlos en orden inverso al introducido.
//	3. Leer 5 n�meros por teclado y a continuaci�n realizar la media de los n�meros positivos, la
//		media de los negativos y contar el n�mero de ceros.
//	4. Leer 10 n�meros enteros. Debemos mostrarlos en el siguiente orden: el primero, el �ltimo, el
//		segundo, el pen�ltimo, el tercero, etc.
//	5. Leer por teclado dos tablas de 10 n�meros enteros y mezclarlas en una tercera de la forma: el 1�
//		de A, el 1� de B, el 2� de A, el 2� de B, etc.
//	6. Leer los datos correspondientes a dos tablas de 12 elementos num�ricos, y mezclarlos en una tercera
//		de la forma:
//		3 de la tabla A, 3 de la B, otros 3 de A, otros 3 de la B, etc
//	7. Leer por teclado una serie de 10 n�meros enteros. 
//		La aplicaci�n debe indicarnos si los n�meros est�n ordenados de forma creciente, decreciente, 
//		o si est�n desordenados.
//	8. Dise�ar una aplicaci�n que declare una tabla de 10 elementos enteros. Leer mediante el teclado 8 
//		n�meros. Despu�s se debe pedir un n�mero y una posici�n, insertarlo en la posici�n indicada, desplazando 
//		los que est�n detr�s.
//	9. Crear un programa que lea por teclado una tabla de 10 n�meros enteros y la desplace una posici�n hacia 
//		abajo: el primero pasa a ser el segundo, el segundo pasa a ser el tercero y as� sucesivamente. El 
//		�ltimo pasa a ser el primero. 
//	10. �dem, desplazar N posiciones (N es introducido por el usuario).
//	11. Leer 5 elementos num�ricos que se introducir�n ordenados de forma creciente. �stos los guardaremos en 
//		una tabla de tama�o 10. Leer un n�mero N, e insertarlo en el lugar adecuado para que la tabla contin�e ordenada.
//	12. Leer por teclado una tabla de 10 elementos num�ricos enteros y una posici�n (entre 0 y 9). Eliminar el 
//		elemento situado en la posici�n dada sin dejar huecos. 
//	13. Leer 10 enteros. Guardar en otra tabla los elementos pares de la primera, y a continuaci�n los elementosimpares.
//		Realizar dos versiones: una trabajando con los valores y otra trabajando con los �ndices.
//	14. Leer dos series de 10 enteros, que estar�n ordenados crecientemente. Copiar (fusionar) las dos tablas
//		en una tercera, de forma que sigan ordenados. 
//	15. Leer 10 enteros ordenados crecientemente. Leer N y buscarlo en la tabla. Se debe mostrar la posici�n en que
//		se encuentra. Si no est�, indicarlo con un mensaje. 
//	16. Queremos desarrollar una aplicaci�n que nos ayude a gestionar las notas de un centro educativo. Cada grupo
//		(o clase) est� compuesto por 5 alumnos. Se pide leer las notas del primer, segundo y tercer trimestre de un grupo.
//		Debemos mostrar al final: la nota media del grupo en cada trimestre, y la media del alumno que se encuentra en la
//		posici�n N (N se lee por teclado). 
}