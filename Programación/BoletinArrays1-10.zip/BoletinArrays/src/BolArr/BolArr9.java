package BolArr;
import java.util.Scanner;

//	9. Crear un programa que lea por teclado una tabla de 10 n�meros enteros y la desplace una posici�n hacia 
//	abajo: el primero pasa a ser el segundo, el segundo pasa a ser el tercero y as� sucesivamente. El 
//	�ltimo pasa a ser el primero.
public class BolArr9 {
 
	public static void main(String[] args) {
		
		int num[] = new int[10];
		int extra, aux;
		
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < num.length; i++) {
		System.out.println("Introduce el valor en posici�n " + i);
		num[i] = sc.nextInt();
		}
		
		extra=num[9];
		
		for (int i=0; i < num.length; i ++ ) {
			aux=num[i];
			num[i]=extra;
			extra=aux;
		}
		
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i] + " ");
		}
		sc.close();
	}
}
