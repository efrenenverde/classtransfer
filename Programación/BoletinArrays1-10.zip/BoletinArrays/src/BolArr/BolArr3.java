package BolArr;

import java.util.Scanner;

//3. Leer 5 n�meros por teclado y a continuaci�n realizar la media de los n�meros positivos, la
//media de los negativos y contar el n�mero de ceros.
public class BolArr3 {

	public static void main(String[] args) {
		int num[] = new int[5];

		Scanner sc = new Scanner(System.in);

		int totpos = 0, totneg = 0, ceros = 0, numpos = 0, numneg = 0;

		for (int i = 0; i < 5; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num[i] = sc.nextInt();
			if (num[i] > 0) {
				totpos += num[i];
				numpos++;
			} else if (num[i] < 0) {
				totneg += num[i];
				numneg++;
			} else {
				ceros++;
			}
		}

		if (numpos != 0) {
			System.out.println("La media de los n�meros positivos es " + totpos / numpos);
		} else {
			System.out.println("No se han introducido n�meros positivos");
		}
		if (numneg != 0) {
			System.out.println("La media de los n�meros negativos es " + totneg / numneg);
		} else {
			System.out.println("No se han introducido n�meros negativos");
		}
		System.out.println("Se han introducido esta cantidad de ceros: " + ceros);

		sc.close();
	}
}