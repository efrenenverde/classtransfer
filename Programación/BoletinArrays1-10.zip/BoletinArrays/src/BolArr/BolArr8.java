package BolArr;
import java.util.Scanner;

//8. Dise�ar una aplicaci�n que declare una tabla de 10 elementos enteros. Leer mediante el teclado 8 
//n�meros. Despu�s se debe pedir un n�mero y una posici�n, insertarlo en la posici�n indicada, desplazando 
//los que est�n detr�s.
public class BolArr8 {

	public static void main(String[] args) {
		
		int num[] = new int[10];
		int extra, pos, aux;
		
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < num.length-2; i++) {
		System.out.println("Introduce el valor en posici�n " + i);
		num[i] = sc.nextInt();
		}
		
		System.out.println("�Qu� valor quieres a�adir?");
		extra = sc.nextInt();
		
		System.out.println("�En qu� posicion?");
		pos = sc.nextInt();
		
		for (int i=pos; i < num.length-1; i ++ ) {
			aux=num[i];
			num[i]=extra;
			extra=aux;
		}
		
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i] + " ");
		}
		sc.close();
	}
}
