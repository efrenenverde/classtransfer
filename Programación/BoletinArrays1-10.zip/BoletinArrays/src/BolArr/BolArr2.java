package BolArr;
import java.util.Scanner;

//2. Leer 5 n�meros y mostrarlos en orden inverso al introducido.
public class BolArr2 {

		public static void main(String[] args) {
		int num[]= new int[5];
		Scanner sc= new Scanner(System.in);
		
		for (int i = 0; i<5;i++) {
			System.out.println("Introduce el valor en posici�n "+i);
			num[i]=sc.nextInt();
		}
		for (int i = 4; i>-1;i--) {
			System.out.print(num[i]+" ");
		}
		sc.close();
		}
	}
