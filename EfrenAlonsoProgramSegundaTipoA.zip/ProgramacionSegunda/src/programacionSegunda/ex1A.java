package programacionSegunda;

import java.util.Scanner;

/*
 * Leer por teclado una tabla de 10 elementos num�ricos enteros
 * y una posici�n (entre 0 y 9). Eliminar el elemento situado en
 * la posici�n dada sin dejar huecos.
 */
public class ex1A {

	public static void main(String[] args) {

		//Inicializamos los dos arrays que necesitaremos y el scanner
		Scanner sc = new Scanner(System.in);
		int fi[] = new int[9];
		int num[] = new int[10];

		//Aqu� pedimos que llene el primer array con 10 posiciones
		for (int i = 0; i < num.length; i++) {
			System.out.println("Escribe el n�mero en posici�n " + i);
			num[i] = sc.nextInt();
		}
		
		//Pedimos que introduzca la posici�n a eliminar
		System.out.println("�Cual es la posici�n del n�mero que quieres eliminar? (Del 0 al 9)");
		int pos = sc.nextInt();

		//Desde la posici�n a eliminar, movemos todos los valores un paso a la izquierda
		for (int i = pos; i < num.length; i++) {
			if (i<num.length-1)
				num[i]=num[i+1];
		}
		
		//Cubrimos un nuevo array, con una posici�n menos para que no queden huecos, con el anterior
		for (int i = 0; i < fi.length; i++)
			fi[i]=num[i];
		
		//Y lo imprimimos para comprobar que est� correcto
		for (int i = 0; i < fi.length; i++) {
			System.out.print(fi[i]+" ");
		}
	sc.close();
	}

}
