package programacionSegunda;

import java.util.Scanner;

/*
 * Crea un programa en Java que solicite al usuario dos cadenas
 * de caracteres y que devuelva la primera cadena, pero transformando
 * en may�sculas la parte que coincide con la segunda cadena introducida.
 * Por ejemplo, si se introducen las cadenas �Este es mi amigo Juan� y �amigo�,
 * devolver� �Este es mi AMIGO Juan�
 */
public class ex4A {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		//Pedimos una cadena
		System.out.println("Introduce la cadena");
		String cadena = sc.nextLine();

		//Y una subcadena que vayamos a poner en mayusculas
		System.out.println("Introduce la subcadena");
		String substring = sc.nextLine();

		//Si la subcadena existe, modificamos la cadena principal con la cadena
		//modificada que contiene la parte necesaria en mayusculas
		if (cadena.indexOf(substring) == -1) {
			System.out.println("La subcadena no exsiste dentro de la cadena");
		} else {
			cadena = cadena.replace(substring, substring.toUpperCase());
		}

		//Y lo imprimimos para comprobar que todo ha ido bien
		System.out.println(cadena);
		
		sc.close();
	}
}
