package programacionSegunda;

import java.util.ArrayList;

/*Escriba un programa que cree dos arrayLists de paises, que ser�n strings: Espa�a, Portugal, Francia, etc., ambos de tama�o siete
 * y con valores repetidos entre los dos.
* Con posterioridad dicho programa comparar� ambos arrayLists y almacenar� en un tercer arrayList los paises repetidos de ambos.
* Pista: utilice un bucle foreach y el m�todo conteins.
*/
public class ex5A {
	
	public static void main(String[] args) {

		//Creamos un primer ArrayList con paises
		ArrayList<String> arr0 = new ArrayList<String>();
		arr0.add("Espa�a");
		arr0.add("Francia");
		arr0.add("Portugal");
		arr0.add("Inglaterra");
		arr0.add("Congo");
		arr0.add("USA");
		arr0.add("Australia");
		
		//Segundo ArrayList, con otros paises y algunos que coincidan
		ArrayList<String> arr1 = new ArrayList<String>();
		arr1.add("Venezuela");
		arr1.add("Alemania");
		arr1.add("Congo");
		arr1.add("Bulgaria");
		arr1.add("Portugal");
		arr1.add("Chile");
		arr1.add("Espa�a");
		
		//Tercer ArrayList vac�o que llenaremos a continuaci�n
		ArrayList<String> arr2 = new ArrayList<String>();
		
		//Bucle anidado, compara la primera palabra del array0 con cada una de las palabras
		//del array1 antes de pasar a la siguiente palabra del array0
		//Si encuentra una coincidencia, guarda esa palabra en el array2
		for(int i = 0; i < arr0.size(); i++) 
			for (int j = 0; j < arr1.size(); j++) 
				if(arr1.get(j).contains(arr0.get(i)))
					arr2.add(arr0.get(i));
		
		//Imprimimos el array2 para comprobar que todo ha salido correctamente
		System.out.println(arr2.toString());
	}
}
