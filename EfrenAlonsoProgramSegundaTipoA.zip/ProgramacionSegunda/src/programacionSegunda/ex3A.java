package programacionSegunda;

import java.util.Scanner;

/*
 * Hacer un programa que al recibir como datos dos cadenas
 * de caracteres forme una tercera cadena intercalando los
 * caracteres de las palabras de las cadenas recibidas.
 */
public class ex3A {
	public static void main(String[] args) {

		//Creamos tres cadenas, y llenamos dos de ellas con informaci�n.
		Scanner sc = new Scanner(System.in);
		String cadenaConjunta = "";

		System.out.println("Introduce la primera cadena");
		String cadena1 = sc.next();

		System.out.println("Introduce la segunda cadena");
		String cadena2 = sc.next();
		
		//Completamos la tercera cadena letra a letra con las otras dos
		//La longitud de la nueva cadena ser� igual a la suma de las otras dos,
		//Dejaremos de a�adir de una cadena peque�a cuando se terminen las letras de esa cadena
		for (int i = 0; i < (cadena1.length() + cadena2.length()); i++) {
			if (i < cadena1.length()) {
				cadenaConjunta=cadenaConjunta+cadena1.charAt(i);
			}
			if (i < cadena2.length()) {
				cadenaConjunta=cadenaConjunta+cadena2.charAt(i);
			}
		}
		
		//Aunque no lo pide, imprimimos la cadena final para debugear
		System.out.println(cadenaConjunta);
		sc.close();
	}
}
