package programacionSegunda;

/*
 * Genera un array de 60 posiciones enteras que tomaran valores entre 0 y 100.
 * Separe en dos matrices los valores (no las posiciones) pares e impares.
 * Ordene ambos arrays por el m�todo Quicksort. Considere el cero par.
 */
public class ex2A {

	public static void main(String[] args) {

		// Inicializamos el array principal y dos variables para luego
		int num[] = new int[60];
		int npar = 0, nodd = 0;

		// Llenamos el array con n�meros aleatorios
		for (int i = 0; i < num.length; i++) {
			num[i] = (int) (Math.random() * 101);
		}

		// Contamos cuantos de esos n�meros son pares y cuantos impares
		// (Contando el 0 como par)
		for (int i = 0; i < num.length; i++) {
			if (num[i] % 2 == 0) {
				npar++;
			} else {
				nodd++;
			}
		}

		// Creamos dos nuevos arrays, con posiciones iguales al n�mero de
		// pares o impares que hayamos contado
		int par[] = new int[npar];
		int odd[] = new int[nodd];

		// Reseteamos las dos variabes de cuenta para ahorrar memoria en lugar
		// de crear unas nuevas
		npar = 0;
		nodd = 0;

		//Repartimos el array grande entre los dos peque�os, poniendo cada numero
		//en el que le corresponda
		for (int i = 0; i < num.length; i++) {
			if (num[i] % 2 == 0) {
				par[npar] = num[i];
				npar++;
			} else {
				odd[nodd] = num[i];
				nodd++;
			}
		}

		//Aplicamos Quicksort para ordenar estos arrays
		Quicksort(par);
		Quicksort(odd);
		
		// A�ado esto para ver en pantalla el resultado, aunque el ejercicio no lo pide
		// Primero los impares y luego los pares.
		for (int i = 0; i < odd.length; i++) 
			System.out.print(odd[i] + " ");
		
		System.out.println(" ");
		
		for (int i = 0; i < par.length; i++) 
			System.out.print(par[i] + " ");
	}

	//Metodo: Quicksort
	static int[] Quicksort(int num[]) {
		//Este bucle recorre el array tantas veces como posiciones tenga
		for (int i = 0; i < num.length - 1; i++) 
			//En cada vuelta, compara de una en una las posiciones con la siguiente
			// (menos la �ltima, claro) y las cambia si la primera es mayor que la siguiente.
			for (int j = 0; j < num.length - 1; j++) 
				if (num[j] > num[j + 1]) {
					int temp = num[j + 1];
					num[j + 1] = num[j];
					num[j] = temp;
				}
		return num;
	}
	
}
