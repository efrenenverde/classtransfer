package BolArr;

import java.util.Scanner;

//10. �dem, desplazar N posiciones (N es introducido por el usuario).
public class BolArr10 {

	public static void main(String[] args) {

		int num[] = new int[10];
		int extra, aux, tope;

		Scanner sc = new Scanner(System.in);

		for (int i = 0; i < num.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num[i] = sc.nextInt();
		}

		System.out.println("�Cu�ntas posiciones quieres desplazar?");
		tope = sc.nextInt();

		for (int j = 0; j < tope; j++) {
			extra=num[9];
			for (int i = 0; i < num.length; i++) {
				aux = num[i];
				num[i] = extra;
				extra = aux;
			}
		}
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i] + " ");
		}
		sc.close();
	}

}
