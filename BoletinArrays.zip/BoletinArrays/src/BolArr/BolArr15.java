package BolArr;

import java.util.Scanner;

//15. Leer 10 enteros ordenados crecientemente. Leer N y buscarlo en la tabla. Se debe mostrar la posici�n en que
//se encuentra. Si no est�, indicarlo con un mensaje.
public class BolArr15 {

	public static void main(String[] args) {

		int num1[] = new int[10];
		int pos;
		boolean found = false;

		Scanner sc = new Scanner(System.in);

		// Rellenamos el primer array
		System.out.println("Completa el array de forma creciente");
		for (int i = 0; i < num1.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num1[i] = sc.nextInt();
		}
		// Leemos el n�mero que se quiere buscar
		System.out.println("Indica qu� n�mero quieres comprobar");
		pos = sc.nextInt();

		// Buscamos pos dentro del array
		for (int i = 0; i < num1.length; i++) {
			if (num1[i] == pos) {
				System.out.println("El n�mero " + pos + " est� en la posici�n " + i);
				found = true;
			}
		}
		if (!found) {
			System.out.println("El n�mero " + pos + " no se encuentra en el array");
		}
		sc.close();
	}
}