package BolArr;
import java.util.Scanner;

//4. Leer 10 n�meros enteros. Debemos mostrarlos en el siguiente orden: el primero, el �ltimo, el
//segundo, el pen�ltimo, el tercero, etc.
public class BolArr04 {
	public static void main(String[] args) {
		int num[]= new int[10];
		Scanner sc= new Scanner(System.in);
		
		for (int i = 0; i<10;i++) {
			System.out.println("Introduce el valor entero en posici�n "+i);
			num[i]=sc.nextInt();
		}
		for (int i = 0; i<5;i++) {
			System.out.print(num[i]+" "+num[9-i]+" ");
		}
	sc.close();
	}
}