package BolArr;
import java.util.Scanner;

//7. Leer por teclado una serie de 10 n�meros enteros. 
//La aplicaci�n debe indicarnos si los n�meros est�n ordenados de forma creciente, decreciente, 
//o si est�n desordenados.
public class BolArr07 {

	public static void main(String[] args) {
		int num[] = new int[10];
		
		boolean creciente=true;
		boolean decreciente=true;
		
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < num.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num[i] = sc.nextInt();
		}
		
		for (int i = 0; i < num.length-1; i++) {
			if (num[i] < num[i+1]) {
				decreciente=false;
			}
			if (num[i] > num[i+1]) {
				creciente=false;
			}
		}
		if (creciente && decreciente) {
			System.out.println("Esta serie est� formada por un mismo n�mero 10 veces");
		}
		else if (creciente) {
			System.out.println("Est� ordenado de forma creciente");
		}
		else if (decreciente) {
			System.out.println("Est� ordenado de forma decreciente");
		}
		else {
			System.out.println("Est� desordenado");
		}
	sc.close();
	}
}
