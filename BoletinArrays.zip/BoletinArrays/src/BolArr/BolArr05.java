package BolArr;

import java.util.Scanner;

//5. Leer por teclado dos tablas de 10 n�meros enteros y mezclarlas en una tercera de la forma: el 1�
//de A, el 1� de B, el 2� de A, el 2� de B, etc.
public class BolArr05 {

	public static void main(String[] args) {
		int num1[] = new int[10];
		int num2[] = new int[10];
		int num3[] = new int[20];
		Scanner sc = new Scanner(System.in);
		System.out.println("GRUPO 1");
		for (int i = 0; i < num1.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num1[i] = sc.nextInt();
		}
		System.out.println("GRUPO 2");
		for (int i = 0; i < num2.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num2[i] = sc.nextInt();
		}
		for (int i = 0; i < num3.length/2; i ++) {
			num3[i*2] = num1[i];
			num3[i*2 + 1] = num2[i];
		}
		for (int i = 0; i < num3.length; i++) {
			System.out.print(num3[i] + " ");
		}
		sc.close();
	}
}
