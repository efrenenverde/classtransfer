package BolArr;

import java.util.Scanner;

//11. Leer 5 elementos num�ricos que se introducir�n ordenados de forma creciente. �stos los guardaremos en 
//una tabla de tama�o 10. Leer un n�mero N, e insertarlo en el lugar adecuado para que la tabla contin�e ordenada.
public class BolArr11 {

	public static void main(String[] args) {

		int num[] = new int[10];
		int add, aux = 0;

		Scanner sc = new Scanner(System.in);

		System.out.println("Rellena el siguiente array con numeros ordenados de forma creciente.");
		for (int i = 0; i < num.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num[i] = sc.nextInt();
		}
		
		System.out.println("Introduce un n�mero que posicionar en la variable");
		add = sc.nextInt();
		
		for (int i=0; i<num.length;i++) {
			if (add <= num[i]) {
				aux=num[i];
				num[i]=add;
				add=aux;
			}
		}
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i] + " ");
		}		
	sc.close();
	}
}	
