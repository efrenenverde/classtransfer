package BolArr;

import java.util.Scanner;

//13. Leer 10 enteros. Guardar en otra tabla los elementos pares de la primera, y a continuaci�n los elementos impares.
//Realizar dos versiones: una trabajando con los valores y otra trabajando con los �ndices.
public class BolArr13_valores {

	public static void main(String[] args) {

		int num[] = new int[10];
		int num2[] = new int[10];
		int cont = 0;

		Scanner sc = new Scanner(System.in);

		// Rellenamos el array
		for (int i = 0; i < num.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num[i] = sc.nextInt();
		}
		// Lo mostramos
		System.out.println("Array Original");
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i] + " ");
		}
		// Rellenamos un nuevo array con los n�meros pares del primero
		for (int i = 0; i < num.length; i++) {
			if (num[i] % 2 == 0) {
				num2[cont]=num[i];
				cont++;
			}
		}
		// Mostramos el segundo tras la primera vuelta
				System.out.println("\nArray solo con los pares");
				for (int i = 0; i < num2.length; i++) {
					System.out.print(num2[i] + " ");
				}
		// Rellenamos un nuevo array con los n�meros impares del primero
		for (int i = 0; i < num.length; i++) {
			if (num[i] % 2 != 0) {
				num2[cont]=num[i];
				cont++;
			}
		}
		// Mostramos el segundo tras la segunda vuelta
		System.out.println("\nArray segundo completo");
		for (int i = 0; i < num2.length; i++) {
			System.out.print(num2[i] + " ");
		}
		
		sc.close();
	}
}
