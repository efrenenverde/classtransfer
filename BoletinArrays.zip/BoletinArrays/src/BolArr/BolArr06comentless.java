package BolArr;

import java.util.Scanner;

public class BolArr06comentless {

	public static void main(String[] args) {

		int num1[] = new int[12];
		int num2[] = new int[12];
		int num3[] = new int[24];

		Scanner sc = new Scanner(System.in);

		System.out.println("GRUPO 1");
		for (int i = 0; i < num1.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num1[i] = sc.nextInt();
		}
		System.out.println("GRUPO 2");
		for (int i = 0; i < num2.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num2[i] = sc.nextInt();
		}

		for (int i = 0; i < num3.length / 6; i++) {
			for (int j = 0; j < 3; j++) {
				num3[(i * 6) + j] = num1[(i * 3) + j];
			}
			for (int j = 0; j < 3; j++) {
				num3[(i * 6) + j + 3] = num2[(i * 3) + j];
			}
		}

		for (int i = 0; i < num3.length; i++) {
			System.out.print(num3[i] + " ");
		}
		
		sc.close();
	}
}
