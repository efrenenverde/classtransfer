package BolArr;

import java.util.Scanner;

//12. Leer por teclado una tabla de 10 elementos num�ricos enteros y una posici�n (entre 0 y 9). Eliminar el 
//elemento situado en la posici�n dada sin dejar huecos. 
public class BolArr12 {

	public static void main(String[] args) {

		int num[] = new int[10];
		int pos;

		Scanner sc = new Scanner(System.in);

		for (int i = 0; i < num.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num[i] = sc.nextInt();
		}

		System.out.println("�Qu� posici�n quieres eliminar?");
		pos = sc.nextInt();

		for (int i = pos; i < num.length - 1; i++) {
			num[i] = num[i + 1];
		}
		num[num.length]=0;
		// Mostrar por pantalla
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i] + " ");
		}
		sc.close();
	}

}
