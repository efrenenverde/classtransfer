package BolArr;

import java.util.Scanner;

//16. Queremos desarrollar una aplicaci�n que nos ayude a gestionar las notas de un centro educativo. Cada grupo
//(o clase) est� compuesto por 5 alumnos. Se pide leer las notas del primer, segundo y tercer trimestre de un grupo.
//Debemos mostrar al final: la nota media del grupo en cada trimestre, y la media del alumno que se encuentra en la
//posici�n N (N se lee por teclado). 
public class BolArr16 {
	
	// M�todo para calcular la media de cada trimestre
	private static float mediaEval(int eval[]) {
		int sum = 0;
		for (int i=0; i < eval.length; i++) {
			sum += eval[i];
		}
		return sum/eval.length;
	}

	public static void main(String[] args) {

		int eval1[] = new int[5];
		int eval2[] = new int[5];
		int eval3[] = new int[5];
		int alum;

		Scanner sc = new Scanner(System.in);

		// Rellenamos el primer array
		System.out.println("Introduce las notas del primer trimestre");
		for (int i = 0; i < eval1.length; i++) {
			System.out.println("Introduce la nota del alumno " + i);
			eval1[i] = sc.nextInt();
		}
		// Rellenamos el segundo array
		System.out.println("Introduce las notas del segundo trimestre");
		for (int i = 0; i < eval2.length; i++) {
			System.out.println("Introduce la nota del alumno " + i);
			eval2[i] = sc.nextInt();
		}
		// Rellenamos el tercer array
		System.out.println("Introduce las notas del tercer trimestre");
		for (int i = 0; i < eval3.length; i++) {
			System.out.println("Introduce la nota del alumno " + i);
			eval3[i] = sc.nextInt();
		}
		//Mostramos las medias
		System.out.println("La media del primer trimestre es "+mediaEval(eval1)+
				"\nLa media del segundo trimestre es "+mediaEval(eval2)+
				"\nLa media del tercer trimestre es "+mediaEval(eval3));
		
		//Pedimos la posici�n del alumno sobre el que se quiera calcular la media
		System.out.println("�De qu� alumno quieres calcular la media?");
		alum = sc.nextInt();
		
		//Y lo mostramos en pantalla
		System.out.println("La media del alumno "+alum+" es: "+(eval1[alum]+eval2[alum]+eval3[alum])/3);
		sc.close();
	}
}