package BolArr;

import java.util.Scanner;

// 14. Leer dos series de 10 enteros, que estar�n ordenados crecientemente.
// Copiar (fusionar) las dos tablas en una tercera, de forma que sigan ordenados. 
public class BolArr14 {

	public static void main(String[] args) {

//		int num1[] = new int[10];
//		int num2[] = new int[10];
		int num1[] = { 0, 2, 4, 6, 8, 10, 12, 14, 16, 60 };
		int num2[] = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 };
		int num3[] = new int[num1.length + num2.length];
		int cont1 = 0, cont2 = 0;
		boolean done1 = false;

		Scanner sc = new Scanner(System.in);

//		// Rellenamos el primer array
//		System.out.println("Completa el primer array de forma creciente");
//		for (int i = 0; i < num1.length; i++) {
//			System.out.println("Introduce el valor en posici�n " + i);
//			num1[i] = sc.nextInt();
//		}
//		// Rellenamos el segundo array
//		System.out.println("Completa el segundo array de forma creciente");
//		for (int i = 0; i < num2.length; i++) {
//			System.out.println("Introduce el valor en posici�n " + i);
//			num2[i] = sc.nextInt();
//		}
		// Mostramos el primer array.
		System.out.println("\nArray uno");
		for (int i = 0; i < num2.length; i++) {
			System.out.print(num1[i] + " ");
		}
		// Mostramos el segundo array.
		System.out.println("\nArray dos");
		for (int i = 0; i < num2.length; i++) {
			System.out.print(num2[i] + " ");
		}
		// Rellenamos el tercer array con los otros ordenadamente
		for (int i = 0; i < num3.length; i++) {
			if (num1[cont1] <= num2[cont2] && !done1) {
				num3[i] = num1[cont1];
				if (cont1 < num1.length - 1) {
					cont1++;
				} else {
					done1 = true;
				}
			} else {
				num3[i] = num2[cont2];
				if (cont2 < num2.length - 1) {
					cont2++;
				}
			}
		}
		// Mostramos el tercer array.
		System.out.println("\nArray tres");
		for (int i = 0; i < num3.length; i++) {
			System.out.print(num3[i] + " ");
		}
		sc.close();
	}
}