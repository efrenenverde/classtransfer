package BolArr;

import java.util.Scanner;
import java.util.Arrays;

public class BolArr14_2 {

	public static void main(String[] args) {

		int num1[] = { 0, 2, 4, 6, 8, 10, 12, 14, 16, 60 };
		int num2[] = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 };
		int num3[] = new int[num1.length + num2.length];

		Scanner sc = new Scanner(System.in);

		// Mostramos el primer array.
		System.out.println("\nArray uno");
		for (int i = 0; i < num2.length; i++) {
			System.out.print(num1[i] + " ");
		}
		// Mostramos el segundo array.
		System.out.println("\nArray dos");
		for (int i = 0; i < num2.length; i++) {
			System.out.print(num2[i] + " ");
		}
		//Juntamos los dos en un tercero as� a lo loco
		for (int i = 0; i < num3.length; i++) {
			if (i < num1.length)
				num3[i] = num1[i];
			else
				num3[i] = num2[i - num1.length];
		}
		// Mostramos el tercer array sin ordenar.
		System.out.println("\nArray tres");
		for (int i = 0; i < num3.length; i++) {
			System.out.print(num3[i] + " ");
		}
		// Lo ordenamos con el m�todo
		for (int i = 0; i < num3.length - 1; i++) {
			for (int j = 0; j < num3.length - 1; j++) {
				if (num3[j] > num3[j + 1]) {
					int temp = num3[j + 1];
					num3[j + 1] = num3[j];
					num3[j] = temp;
				}
			}
		}
		// Y lo mostramos ilegalmente para aprender a usarlo
		System.out.print("\n");
		System.out.println(Arrays.toString(num3));

		sc.close();
	}
}