package BolArr;

import java.util.Scanner;

public class BolArr06 {

	public static void main(String[] args) {

		// Array 1, contendr� los 12 n�meros que quiera poner el usuario
		int num1[] = new int[12];

		// Array 2, lo mismo que el uno
		int num2[] = new int[12];

		// El array 3 lo iniciamos a 24 ya que va a contener los arrays 1 y 2
		// mezclados segun nuestro bucle
		int num3[] = new int[24];

		Scanner sc = new Scanner(System.in);

		// Lectores para rellenar los arrays 1 y 2, sin m�s
		System.out.println("GRUPO 1");
		for (int i = 0; i < num1.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num1[i] = sc.nextInt();
		}
		System.out.println("GRUPO 2");
		for (int i = 0; i < num2.length; i++) {
			System.out.println("Introduce el valor en posici�n " + i);
			num2[i] = sc.nextInt();
		}

		// Ahora empieza la movida
		// Primero tenemos un bucle for, que va a recorrer el array3 tantas veces como
		// su longitud entre seis, porque en cada vuelta ponemos 6 n�meros
		for (int i = 0; i < num3.length / 6; i++) {

			// En cada vuelta del primer for, declaramos otros dos for,
			// voy a explicar cada parte de la f�rmula a ver si se entiende
			for (int j = 0; j < 3; j++) {

				// En este primer for, vamos a colocar los tres primeros n�meros de los 6 que
				// tenemos que poner
				// la formula es un poco jodida as� que vamos a hacerlo despacito
				// num3[(i*6)+j] aqu� cojemos el array a rellenar, en posici�n igual al n�mero
				// de vueltas que ya hemos dado (i) por seis, ya que en cada paso anterior habremos rellenado 6
				// y a esto le sumamos j, que es quien lleva la cuenta dentro del primer bucle
				// para no ponerlo todo en la misma posici�n
				// num1[(i*3)+j] dentro del array 1, nos vamos a la posici�n i * 3
				// esto nos asegura que en cada paso del bucle, tengamos en cuenta cuantas vueltas
				// hemos dado en i para ubicar la posici�n correspondiente dentro de los arrays de origen
				// Si te fijas esta parte es igual que el posicionador dentro del array3, pero
				// con un 3 en lugar de un 6 porque en cada vuelta de i, los arrays peque�os est�n avanzando 3
				// y ya para acabar le sumamos j para avanzar 3 pasitos en cada vuelta del
				// segundo bucle
				num3[(i * 6) + j] = num1[(i * 3) + j];
			}

			// Ahora llegamos a la segunda parte dentro de cada vuelta donde pondremos los
			// siguientes 3 numeros
			// Es muy similar a la anterior, con los mismos posicionadores con peque�os
			// cambios
			for (int j = 0; j < 3; j++) {

				// num3[(i*6)+j] El �nico cambio en la primera parte, que nos posiciona dentro
				// del array3, es
				// sumar 3 ya que as� nos aseguramos de respetar los 3 otros pasos que hemos
				// dado en el
				// anterior sub-bucle
				// num2[j+(i*3)] esto es absolutamente igual a lo anterior, pero pillando los
				// n�meros que toquen del array2
				// en vez de pillarlos del array1
				num3[(i * 6) + j + 3] = num2[(i * 3) + j];
			}
		}

		// Y para acabar imprimimos en pantalla el array3
		for (int i = 0; i < num3.length; i++) {
			System.out.print(num3[i] + " ");
		}

		sc.close();
	}
}
